package com.example.semana7;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SharedPrefferencs extends AppCompatActivity {
    private EditText et1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_shared_prefferencs);

        et1 = findViewById(R.id.etEmail);
        SharedPreferences preferencs = getSharedPreferences("datos",Context.MODE_PRIVATE);
        et1.setText(preferencs.getString("main", " "));
    }

    public void btn_guardar(View v){
        SharedPreferences preferencs = getSharedPreferences("datos", Context.MODE_PRIVATE);
        SharedPreferences.Editor Obj_editor = preferencs.edit();
        Obj_editor.putString("mail", et1.getText().toString());
        finish();
    }


}